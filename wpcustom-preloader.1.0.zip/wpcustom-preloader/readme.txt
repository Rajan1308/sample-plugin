=== Custom Preloader ===
Contributors: Rajan gupta
Tags: preloader, preload, loader, loading, load
Requires at least: 3.4.0
Tested up to: 6.0
Stable tag: 1.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add preloader to your website easily, compatible with all major browsers.

== Description ==

### WP Preloader 

Add preloader to your website easily, compatible with all major browsers.

== Installation ==

1. Upload the entire `wpcustom-preloader` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

== Configuration ==

1. You will find **WP Placeholder** menu in your WordPress admin screen > Plugins.
2. Goto **WP Placeholder**  and Configure the WP Placeholder Settings as per your design.

=== Screenshots ===
1. Setting page